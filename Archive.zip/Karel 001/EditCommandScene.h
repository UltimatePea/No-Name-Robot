//
//  EditCommandScene.h
//  No Name Robot
//
//  Created by Chen Zhibo on 1/17/15.
//  Copyright (c) 2015 Chen Zhibo. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface EditCommandScene : SKSpriteNode

- (instancetype)initWithSize:(CGSize)size;

@end
